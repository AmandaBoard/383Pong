using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
   [Header("Ball")]
   public GameObject Ball;

   [Header("Player 1")]
   public GameObject RacketLeft;
   public GameObject LeftGoal;

   [Header("Player 2")]
   public GameObject RacketRight;
   public GameObject RightGoal;

    [Header("Score UI")]
    public GameObject LeftScore;
    public GameObject RightScore;

    private int LeftPoints;
    private int RightPoints;

    public void LeftPoint(){
        LeftPoints++;
        LeftScore.GetComponent<TextMeshProUGUI>().text = LeftPoints.ToString();
        ResetPosition();
    }

     public void RightPoint(){
        RightPoints++;
        RightScore.GetComponent<TextMeshProUGUI>().text = RightPoints.ToString();
        ResetPosition();
    }

    private void ResetPosition(){
        Ball.GetComponent<Ball>().BallReset();
        RacketLeft.GetComponent<Paddle>().Reset();
        RacketRight.GetComponent<Paddle>().Reset();

    }


}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{

    public static bool isPaused = false;
    public GameObject PauseMenuUI;

    // Update is called once per frame, checking if recieves escape input
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape)){
            if(isPaused){
                Resume();

            } else {
                Pause();
            }
        }
        
    }
    public void Resume(){
        PauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        isPaused = false;

    }
    void Pause(){
        PauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        isPaused = true;

    }

    public void LoadHelp(){
        Debug.Log("Loading Help...");
        SceneManager.LoadScene("Help");
    }

    public void QuitGame(){
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false; // Stop playmode in the editor
        #else
        Application.Quit(); // Quit the application
        #endif
    }

}


